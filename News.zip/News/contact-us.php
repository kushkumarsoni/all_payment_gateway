<?php
error_reporting(0);
if($_GET['contact_msg']){
$contact_msg = $_GET['contact_msg'];	
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Contact Us Form</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/contact-us.css">
		<!-- Boottrap CSS -->
	</head>
	<body>

		<div class="wrapper">
			<div class="inner">
				<form action="save-contact-us.php" method="post">
					<h3>Contact Us</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
					<label class="form-group">
						<input type="text" class="form-control" name="name" required>
						<span>Your Name</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="number" required>
						<span>Your Mobile Number</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" class="form-control" name="email"  required>
						<span for="">Your Mail</span>
						<span class="border"></span>
					</label>
					<label class="form-group" >
		<textarea name="message" class="form-control" required></textarea>
						<span for="">Your Message</span>
						<span class="border"></span>
					</label>
					<button type="submit" name="submit">Submit 
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
					<button type="submit"><a href="index.php" style="text-decoration: none;color: white;font-weight: bold;">Cancel<i class="zmdi zmdi-arrow-right"></i></a></button>
				</form>
				<?php if($contact_msg){
					?><
					 <div class="alert alert-success" style = 'text-align:center;'><?php echo $contact_msg ;?></div> <?php
				}
				 ?>
			</div>
		</div>
</body>
</html>