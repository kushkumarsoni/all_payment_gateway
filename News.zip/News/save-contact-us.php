<?php
include "config.php";
$contact_msg = "";
if(isset($_POST['submit'])){
$name = mysqli_real_escape_string($conn,$_POST['name']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$number = mysqli_real_escape_string($conn,$_POST['number']);
$message = mysqli_real_escape_string($conn,$_POST['message']);
$sql = "INSERT INTO `contact-us`(name,email,phone_number,message) VALUES('$name','$email','$number','$message')";
$result = mysqli_query($conn,$sql);
$contact_msg = "Thanks,for submited form";
if($result){
header("Location:contact-us.php?contact_msg=$contact_msg");
}else{
echo("Query Failed");
}

//    $html="<table><tr><td>Name</td><td>$name</td></tr><tr><td>Email</td><td>$email</td></tr><tr><td>Mobile</td><td>$number</td></tr><tr><td>Message</td><td>$message</td></tr></table>";
//    include"smtp/PHPMailerAutoload.php";
//    $mail = new PHPMailer(true);
//    $mail->isSMTP();
//    $mail->Host = "smtp.gmail.com";
//    $mail->Port =587;
//    $mail->SMTPSecure = "tls";
//    $mail->SMTPAuth =true;
//    $mail->Username = "kushkumarsoni124@gmail.com";
//    $mail->Password = "kush124@soni";
//    $mail->SetFrom("kushkumarsoni124@gmail.com");
//    $mail->addAddress("softdc1998@gmail.com");
//    $mail->IsHTML(true);
//    $mail->Subject ="New Contact Us Form";
//    $mail->Body ="$html";
//    $mail->SMTPOptions = array('ssl'=>array(
   //       'verify_peer'=>false,
   //       'verify_peer_name'=>false,
   //       'allow_self_signed'=>false
//    ));
// if($mail->send()){
   //    echo "Mail Sent";
// }else{
   //    echo "Error Occurd";
// }

}
?>