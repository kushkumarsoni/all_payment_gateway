<?php
	include "config.php";
	$category_id = $_GET['id'];
	$sql = "DELETE FROM category WHERE category_id = '$category_id'";
	mysqli_query($conn,$sql);
	header("Location:category.php");



?>