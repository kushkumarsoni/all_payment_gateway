<?php
	include "config.php";
	if(empty($_FILES['new-image']['name'])){
		$file_name = $_POST['old-image'];
	}else{
		$error = array();
		$file_name = $_FILES['new-image']['name'];
		$file_size = $_FILES['new-image']['size'];
		$file_tmp_name = $_FILES['new-image']['tmp_name'];
		$file_type = $_FILES['new-image']['type'];
		$file_ext = end(explode('.',$file_name));
		$extensions = array("jpeg","jpg","png");
		if(in_array($file_ext, $extensions) === false){
			$error[] = "This extension is not allowed,Please Choose JPG or PNG";
		}
		if ($file_size > 2097152) {
			$error[] = "This is a Large File Size Please Choose Less than 2Mb";
		}
		if(empty($error) == true){
			$path = "F:/xamp/htdocs/News Website/admin/upload/";
			move_uploaded_file($file_tmp_name, "$path".$file_name);
		}else{
			print_r($error);
			die();
		}
	}
	$sql = "UPDATE post SET title = '{$_POST["post_title"]}',description = '{$_POST["postdesc"]}',category = '{$_POST["category"]}',post_img = '$file_name'
	 WHERE post_id = '{$_POST["post_id"]}';";

	if($_POST['old_category'] != $_POST["category"] ){
	  $sql.= "UPDATE category SET post= post - 1 WHERE category_id = {$_POST['old_category']};";
	  $sql.= "UPDATE category SET post= post + 1 WHERE category_id = {$_POST["category"]};";
	}
	 $result = mysqli_multi_query($conn,$sql);
	 if($result){
	 	header("Location:post.php?msg_id =1");
	 }else{
	 	echo "Query failed";
	 }
?>



