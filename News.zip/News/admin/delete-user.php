<?php 
	include("config.php");
	if($_SESSION['user_role'] ==0){ 
  header("Location:post.php");
 }
	$user_id =  $_GET['id'];
	$sql = "DELETE from user where user_id = '$user_id'";
	if(mysqli_query($conn,$sql)){
		header("Location:users.php");
	}else{
		echo "<p style = 'color:red;text-align:center;'>Can't Delete Record</p>";
	}

?>