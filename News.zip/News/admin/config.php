<?php 

$conn = mysqli_connect("localhost","root","","news_cms") or die("connection failed:".mysqli_connect_error());

?>