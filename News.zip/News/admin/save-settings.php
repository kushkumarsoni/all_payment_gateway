<?php
	include "config.php";
	if(empty($_FILES['logo']['name'])){
		$file_name = $_POST['old_logo'];
	}else{
		$error = array();
		$file_name = $_FILES['logo']['name'];
		$file_size = $_FILES['logo']['size'];
		$file_tmp_name = $_FILES['logo']['tmp_name'];
		$file_type = $_FILES['logo']['type'];
		$file_ext = end(explode('.',$file_name));
		$extensions = array("jpeg","jpg","png");
		if(in_array($file_ext, $extensions) === false){
			$error[] = "This extension is not allowed,Please Choose JPG or PNG";
		}
		if ($file_size > 2097152) {
			$error[] = "This is a Large File Size Please Choose Less than 2Mb";
		}
		if(empty($error) == true){
			$path = "F:/xamp/htdocs/News Website/admin/upload/";
			move_uploaded_file($file_tmp_name, "$path".$file_name);
		}else{
			print_r($error);
			die();
		}
	}
	echo $sql = "UPDATE setting SET websitename = '{$_POST['website_name']}',logo = '{$file_name}', footerdesc = '{$_POST["footer_desc"]}'";
	 $result = mysqli_query($conn,$sql) or die("query failed");
	 if($result){
	 	header("Location:setting.php");
	 }
?>