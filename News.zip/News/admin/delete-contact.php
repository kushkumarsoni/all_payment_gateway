<?php
include "config.php";
$contact_id = $_GET['id'];
 $sql = "DELETE FROM `contact-us` WHERE contact_id = '$contact_id'";
 $result = mysqli_query($conn,$sql);
 if($result){
 	header("Location:contact-us.php");
 }else{
 	echo "Query Failed";
 }


?>