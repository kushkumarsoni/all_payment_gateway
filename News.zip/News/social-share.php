<div class="col-md-2">
  <a class="w-inline-block social-share-btn fb" href="https://www.facebook.com/sharer/sharer.php?u=&t=" title="Share on Facebook" target="_blank" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(document.URL) + '&t=' + encodeURIComponent(document.URL)); return false;">
    <img src="images/Facebook-share-icon.png" height="30" width="30">
  </a>
</div>
<div class="col-md-2">
  <a class="w-inline-block social-share-btn fb" href="https://www.whatsapp.com/sharer/sharer.php?u=&t=" title="Share on Whatsapp" target="_blank" onclick="window.open('https://www.whatsapp.com/sharer/sharer.php?u=' + encodeURIComponent(document.URL) + '&t=' + encodeURIComponent(document.URL)); return false;">
    <img src="images/whatsappimg.png" height="30" width="30">
  </a>
</div>
<div class="col-md-2">
  <a class="w-inline-block social-share-btn tw" href="https://twitter.com/intent/tweet?" target="_blank" title="Tweet" onclick="window.open('https://twitter.com/intent/tweet?text=%20Check%20up%20this%20awesome%20content' + encodeURIComponent(document.title) + ':%20 ' + encodeURIComponent(document.URL)); return false;">
    <img src="images/twitter.png" height="30" width="30">
  </a>
</div>