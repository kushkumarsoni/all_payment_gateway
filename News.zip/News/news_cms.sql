-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2021 at 01:33 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.2.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `post` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `post`) VALUES
(30, 'News', 2),
(31, 'Sports', 2),
(34, 'Education', 3),
(35, 'Fashions', 2);

-- --------------------------------------------------------

--
-- Table structure for table `contact-us`
--

CREATE TABLE `contact-us` (
  `contact_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` int(10) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact-us`
--

INSERT INTO `contact-us` (`contact_id`, `name`, `email`, `phone_number`, `message`) VALUES
(1, 'Raman Verma', 'kush@gmail.com', 1234567890, 'i want meet you urgently.'),
(2, 'Deepak Kumar Chaudhary', 'deepak@gmail.com', 2147483647, 'क्या आप बहुत अच्छे डॉक्टर  है '),
(3, 'Amit Saroj', 'amit@gmail.com', 2147483647, 'Can you check me resume.'),
(4, 'Anupam', 'anupam@gmail.com', 1234567890, 'Hey , this is Anupam.'),
(5, 'Rahul Baghel', 'rahul@gmail.com', 123467809, 'Which subject do you teach.'),
(7, 'Amit Yadav', 'amityadav@gmail.com', 13456870, 'Hey ,  bhai kahi Job mila ki nhi.'),
(8, 'Kapil', 'kapil@gmail.com', 25984610, 'A ja bhai Singsys me phir se.'),
(9, 'Deepak Chaudhary', 'softdc1998@gmail.com', 2147483647, 'This is good website for reading news.');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `post_date` varchar(50) NOT NULL,
  `author` int(11) NOT NULL,
  `post_img` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `title`, `description`, `category`, `post_date`, `author`, `post_img`) VALUES
(36, 'Latest Science Lab in India', 'Latest Science Lab in India', '31', '25 Jan, 2021', 25, 'man.jpg'),
(43, 'Good News For All Drivers', 'PM Modi has decided a new guide line for all drivers in india', '30', '27 Jan, 2021', 27, 'amit.jpg'),
(40, 'Lateset Women Suits', 'Lateset Women Suits.Lateset Women Suits.', '35', '25 Jan, 2021', 25, 't-1-min.jpg'),
(41, 'science ek chamatkar hai', 'science ek chamatkar hai.ek chamatkar hai', '35', '25 Jan, 2021', 25, 'k.png'),
(42, 'Breaking News:Anil Khabar', 'House', '31', '25 Jan, 2021', 26, 'a.png'),
(44, 'Green Advisery for all new drivers', 'The new advisey published by (PMO) government of india.', '31', '27 Jan, 2021', 27, 'deepak (2).jpg'),
(45, 'Good News For all CBSE board\'s student', 'Administrator board of CBSE has decided that the registration of new student\r\ncan deposit only 5000 Rs as a fees in schools .It is decided because the situation of Covid19.', '34', '27 Jan, 2021', 30, 'deepak_yadav.jpg'),
(46, 'Good News For all CBSE board\'s student', 'Good News For all CBSE board\'s student.Good News For all CBSE board\'s student.Good News For all CBSE board\'s student.Good News For all CBSE board\'s student.Good News For all CBSE board\'s student.', '34', '27 Jan, 2021', 30, '1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `websitename` varchar(60) NOT NULL,
  `logo` varchar(60) NOT NULL,
  `footerdesc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`websitename`, `logo`, `footerdesc`) VALUES
('RS News', 'news.jpg', '© Copyright 2021 News | Powered by Kush Study Point');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `role` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `username`, `password`, `role`) VALUES
(30, 'Amit', 'Yadav', 'amityadav@gmail.com', '444e247d5fcc86c3e65cf87672ea9ec4', 0),
(25, 'Kush', 'Soni', 'kush@gmail.com', '3f18b35486f1c84cf05deefdfac3249d', 1),
(26, 'Amit', 'Kumar', 'amit@gmail.com', 'd2b3f63948406cb893544cee035531d3', 0),
(27, 'Jay', 'Prakash Yadav', 'jayprakash@gmail.com', 'f0e7d0d17cff891edbc9cdf92dcd9297', 0),
(29, 'Jay', 'Prakash ', 'jay@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `contact-us`
--
ALTER TABLE `contact-us`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`),
  ADD UNIQUE KEY `post_id` (`post_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `contact-us`
--
ALTER TABLE `contact-us`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
